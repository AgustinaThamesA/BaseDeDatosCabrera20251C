-- ================
-- ROLES Y PERMISOS
-- ===============

-- DROP OWNED BY rol;
-- DROP ROLE rol;

-- Crear roles
CREATE ROLE rol_cliente NOINHERIT;
CREATE ROLE rol_publicador NOINHERIT;
CREATE ROLE rol_administrador SUPERUSER;

-- Crear usuarios y asignar roles
CREATE USER cliente1 WITH PASSWORD 'password';
GRANT rol_cliente TO cliente1;

CREATE USER publicador1 WITH PASSWORD 'password';
GRANT rol_publicador TO publicador1;

CREATE USER admin1 WITH PASSWORD 'password';
GRANT rol_administrador TO admin1;

-- Permisos para clientes
GRANT SELECT ON Cancion, Album, Artista, Plan, fav_cancion, fav_album, fav_artista TO rol_cliente;
GRANT INSERT ON Fav_cancion, Fav_album, Fav_artista, Suscribe TO rol_cliente;

-- Permisos para publicadores
GRANT SELECT, INSERT, UPDATE, DELETE ON Cancion, Album TO rol_publicador;

-- El admin tiene todos los permisos