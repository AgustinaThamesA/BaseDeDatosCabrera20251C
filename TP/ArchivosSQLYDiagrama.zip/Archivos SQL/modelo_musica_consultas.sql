-- ================
-- CONSULTAS
-- ================

-- Listar todas las canciones de la aplicacion
SELECT * FROM Cancion;

-- Listar todos los artistas de la plataforma
SELECT * FROM Artista;

-- Listar todos los albumes, agrupados por artistas
SELECT a.nombre_artista, ARRAY_AGG(al.nombre_album) AS albums
FROM Album al
JOIN Artista a ON al.id_artista = a.id_artista
GROUP BY a.nombre_artista
ORDER BY a.nombre_artista;

-- Publicar canciones
INSERT INTO Cancion (nombre_cancion, duracion, genero, id_artista, nombre_album)
VALUES ('Nueva Melodia', 210, 'Rock', 1, 'Solista Hits');

-- Publicar artistas
INSERT INTO Artista (id_artista, nombre_artista, es_banda)
VALUES (26, 'Los Melodicos', TRUE);

-- Publicar un album
INSERT INTO Album (nombre_album, año, id_artista)
VALUES ('Album Debut', 2025, 2);

-- Actualizar una cancion
UPDATE Cancion
SET duracion = 215
WHERE nombre_cancion = 'Nueva Melodia' AND id_artista = 1;

-- Actualizar un artista
UPDATE Artista
SET nombre_artista = 'Los Melodicos Internacionales'
WHERE id_artista = 26;

-- Actualizar un album
UPDATE Album
SET año = 2026
WHERE nombre_album = 'Album Debut' AND id_artista = 2;

-- Registrar usuarios:
    -- Registrar un cliente (admin)
    INSERT INTO Cliente (id_cliente, nombre_cliente)
    VALUES (100, 'Santiago Pesa');

    -- Registrar un publicador/artista (admin)
    INSERT INTO Artista (id_artista, nombre_artista, es_banda)
    VALUES (100, 'Solista Nuevo', FALSE);

-- Realizar el pago de un plan de suscripcion (usuario con rol_cliente)
INSERT INTO Suscribe (id_cliente, id_plan, forma_pago, es_mensual)
VALUES (100, 1, 'Credito', TRUE);

-- Desregistrar a ususarios:
    -- Desregistrar a un cliente de la aplicacion (admin)
    DELETE FROM Cliente WHERE id_cliente = 100;

    -- Desregistrar a un artista de la aplicacion (admin)
    DELETE FROM Artista WHERE id_artista =100;

-- Mostrar las canciones mas populares ordenadas por cantidad de favoritos
SELECT fc.nombre_cancion, COUNT(fc.id_cliente) AS cantidad_favoritos
FROM fav_cancion fc
GROUP BY fc.nombre_cancion
ORDER BY cantidad_favoritos DESC;

-- Mostrar los artistas mas populares basandose en la cantidad de canciones favoritas
SELECT a.nombre_artista, COUNT(fc.id_cliente) AS cantidad_favoritos
FROM Fav_cancion fc
join Artista a ON fc.id_artista = a.id_artista
GROUP BY a.nombre_artista
ORDER BY cantidad_favoritos DESC;




