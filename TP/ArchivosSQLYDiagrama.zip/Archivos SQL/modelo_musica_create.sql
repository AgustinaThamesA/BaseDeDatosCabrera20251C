-- ========================
-- Archivo: modelo_musica_create.sql
-- Contiene todas las definiciones de tablas y triggers
-- ========================

-- Borrado de tablas
-- DROP TABLE IF EXISTS fav_album CASCADE;
-- DROP TABLE IF EXISTS fav_artista CASCADE;
-- DROP TABLE IF EXISTS fav_cancion CASCADE;
-- DROP TABLE IF EXISTS cancion CASCADE;
-- DROP TABLE IF EXISTS album CASCADE;
-- DROP TABLE IF EXISTS artista CASCADE;
-- DROP TABLE IF EXISTS suscribe CASCADE;
-- DROP TABLE IF EXISTS plan CASCADE;
-- DROP TABLE IF EXISTS cliente CASCADE;

-- Extensión para triggers en PostgreSQL
CREATE EXTENSION IF NOT EXISTS plpgsql;

-- Tablas principales
CREATE TABLE Cliente (
    id_cliente INT PRIMARY KEY,
    nombre_cliente VARCHAR(100) NOT NULL
);

CREATE TABLE Plan (
    id_plan INT PRIMARY KEY,
    nombre_plan VARCHAR(100) CHECK (nombre_plan IN ('Gratuito', 'Pago')),
    precio DECIMAL(10,2) NOT NULL
);

CREATE TABLE Suscribe (
    id_cliente INT,
    id_plan INT,
    forma_pago VARCHAR(50) CHECK (forma_pago IN ('Ninguna', 'Debito', 'Transferencia', 'Credito')),
    es_mensual BOOLEAN,
    precio_final DECIMAL(10,2),
    PRIMARY KEY (id_cliente, id_plan),
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente) ON DELETE CASCADE,
    FOREIGN KEY (id_plan) REFERENCES Plan(id_plan)
);

CREATE TABLE Artista (
    id_artista INT PRIMARY KEY,
    nombre_artista VARCHAR(100) NOT NULL,
    es_banda BOOLEAN
);

CREATE TABLE Album (
    nombre_album VARCHAR(100),
    año INT,
    id_artista INT,
    PRIMARY KEY (nombre_album, id_artista),
    FOREIGN KEY (id_artista) REFERENCES Artista(id_artista)
);

CREATE TABLE Cancion (
    nombre_cancion VARCHAR(100),
    duracion INT,
    genero VARCHAR(50) CHECK (genero IN ('Rock', 'Jazz', 'Clasica', 'Latina', 'Pop', 'Electronica', 'Indie', 'Hip Hop', 'Reggae', 'Folk', 'Blues', 'Country', 'R&B', 'Gospel', 'Punk', 'Salsa', 'Techno', 'Opera', 'K-Pop', 'Funk')),
    id_artista INT,
    nombre_album VARCHAR(100),
    PRIMARY KEY (nombre_cancion, id_artista),
    FOREIGN KEY (id_artista) REFERENCES Artista(id_artista),
    FOREIGN KEY (nombre_album, id_artista) REFERENCES Album(nombre_album, id_artista)
);

CREATE TABLE Fav_cancion (
    id_cliente INT,
    nombre_cancion VARCHAR(100),
    id_artista INT,
    PRIMARY KEY (id_cliente, nombre_cancion, id_artista),
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente) ON DELETE CASCADE,
    FOREIGN KEY (nombre_cancion, id_artista) REFERENCES Cancion(nombre_cancion, id_artista)
);

CREATE TABLE Fav_artista (
    id_cliente INT,
    id_artista INT,
    PRIMARY KEY (id_cliente, id_artista),
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente) ON DELETE CASCADE,
    FOREIGN KEY (id_artista) REFERENCES Artista(id_artista)
);

CREATE TABLE Fav_album (
    id_cliente INT,
    nombre_album VARCHAR(100),
    id_artista INT,
    PRIMARY KEY (id_cliente, nombre_album, id_artista),
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente) ON DELETE CASCADE,
    FOREIGN KEY (nombre_album, id_artista) REFERENCES Album(nombre_album, id_artista)
);

-- ================
-- TRIGGERS
-- ================

-- Trigger para calcular el precio_final automáticamente al insertar en Suscribe
CREATE OR REPLACE FUNCTION before_insert_suscribe_func()
RETURNS TRIGGER AS $$
DECLARE
    plan_precio DECIMAL(10,2);
BEGIN
    SELECT precio INTO plan_precio FROM Plan WHERE id_plan = NEW.id_plan;

    IF NOT NEW.es_mensual THEN
        NEW.precio_final := plan_precio * 12 * 0.9; -- 10% de descuento por pago anual
    ELSE
        NEW.precio_final := plan_precio;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS before_insert_suscribe ON Suscribe;
CREATE TRIGGER before_insert_suscribe
BEFORE INSERT ON Suscribe
FOR EACH ROW
EXECUTE FUNCTION before_insert_suscribe_func();

-- Trigger para agregar la suscripción gratuita automáticamente al insertar el cliente
CREATE OR REPLACE FUNCTION after_insert_cliente_func()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO Suscribe (id_cliente, id_plan, forma_pago, es_mensual)
    VALUES (NEW.id_cliente, 0, 'Ninguna', TRUE);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS after_insert_cliente ON Cliente;
CREATE TRIGGER after_insert_cliente
AFTER INSERT ON Cliente
FOR EACH ROW
EXECUTE FUNCTION after_insert_cliente_func();

-- Trigger para eliminar la suscripción gratuita si el cliente se suscribe a un plan pago
CREATE OR REPLACE FUNCTION after_insert_suscribe_func()
RETURNS TRIGGER AS $$
BEGIN
    -- Solo elimina el plan gratuito si se está agregando un plan distinto al 0 (Gratuito)
    IF NEW.id_plan <> 0 THEN
        DELETE FROM Suscribe
        WHERE id_cliente = NEW.id_cliente AND id_plan = 0;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS after_insert_suscribe ON Suscribe;
CREATE TRIGGER after_insert_suscribe
AFTER INSERT ON Suscribe
FOR EACH ROW
EXECUTE FUNCTION after_insert_suscribe_func();